Spike detection routines from Ted Brookings.
Also includes a whole host of other things.